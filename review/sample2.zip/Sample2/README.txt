Pocket Games Sample 2

A small Windows demo program written by the Pocket Games developer, for trying
Pocket Games' import flow. It is a simple paddle-and-bricks game drawn with
Direct3D 11. It contains no third-party code.

To import it on iPhone or iPad:
1. Tap sample2.zip in the Files app to unzip it. You get a folder "Sample2".
2. In Pocket Games: Library > + > choose the "Sample2" folder.
3. Tap the game, then Play.

Controls:
- Left stick, d-pad or the arrow keys: move the paddle.
- A, Space or Enter: launch the ball.
- B or Esc: quit.
The top-left number is the score; the top-right number is the round.
